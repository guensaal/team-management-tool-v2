package com.teamtool.app

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

// ---------------------------------------------------------------
// LOGIN SCREEN
// ---------------------------------------------------------------
@Composable
fun LoginScreen(
    onNavigateToRegister: () -> Unit,
    onLoginSuccess: () -> Unit
) {
    val context = LocalContext.current
    val auth = FirebaseAuth.getInstance()

    // Hier speichere ich die Eingaben vom Benutzer
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center
    ) {

        Text("Login", style = MaterialTheme.typography.titleLarge)

        Spacer(Modifier.height(12.dp))

        // Eingabefeld Email
        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("E-Mail") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(8.dp))

        // Eingabefeld Passwort
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Passwort") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(12.dp))

        // Login-Button
        Button(
            onClick = {
                // Check: Habe ich überhaupt etwas eingegeben?
                if (email.isBlank() || password.isBlank()) {
                    Toast.makeText(context, "Bitte E-Mail & Passwort eingeben", Toast.LENGTH_SHORT).show()
                    return@Button
                }

                // Firebase Login
                auth.signInWithEmailAndPassword(email.trim(), password)
                    .addOnSuccessListener {
                        Toast.makeText(context, "Login erfolgreich", Toast.LENGTH_SHORT).show()
                        onLoginSuccess()
                    }
                    .addOnFailureListener { e ->
                        Toast.makeText(context, "Fehler: ${e.message}", Toast.LENGTH_LONG).show()
                    }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Login")
        }

        Spacer(Modifier.height(8.dp))

        // Link zur Registrierung
        TextButton(onClick = onNavigateToRegister, modifier = Modifier.fillMaxWidth()) {
            Text("Noch keinen Account? Jetzt registrieren")
        }
    }
}

// ---------------------------------------------------------------
// REGISTRIERUNGSSCREEN
// ---------------------------------------------------------------
@Composable
fun RegisterScreen(
    onRegistered: () -> Unit,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val auth = FirebaseAuth.getInstance()
    val firestore = FirebaseFirestore.getInstance()

    // Die Eingabedaten aus den Textfeldern
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("Registrieren", style = MaterialTheme.typography.titleLarge)

        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Name") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("E-Mail") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Passwort") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(12.dp))

        // Registrierungs-Button
        Button(
            onClick = {
                // Check auf gültige Eingaben
                if (name.isBlank() || email.isBlank() || password.length < 6) {
                    Toast.makeText(
                        context,
                        "Bitte gültige Daten eingeben (Passwort mind. 6 Zeichen)",
                        Toast.LENGTH_SHORT
                    ).show()
                    return@Button
                }

                // Firebase Registrierung
                auth.createUserWithEmailAndPassword(email.trim(), password)
                    .addOnSuccessListener { result ->
                        val uid = result.user?.uid

                        if (uid == null) {
                            Toast.makeText(context, "Fehler: UID fehlt", Toast.LENGTH_LONG).show()
                            return@addOnSuccessListener
                        }

                        // Ich lege beim Registrieren automatisch ein User-Dokument in Firestore an
                        val userData = mapOf(
                            "name" to name,
                            "email" to email.trim(),
                            "skills" to listOf<String>(),
                            "verfugbarkeiten" to ""
                        )

                        firestore.collection("users")
                            .document(uid)
                            .set(userData)
                            .addOnSuccessListener {
                                Toast.makeText(context, "Account erstellt", Toast.LENGTH_SHORT).show()
                                onRegistered()
                            }
                            .addOnFailureListener { e ->
                                Toast.makeText(context, "DB-Fehler: ${e.message}", Toast.LENGTH_LONG).show()
                            }
                    }
                    .addOnFailureListener { e ->
                        Toast.makeText(context, "Registrierung fehlgeschlagen: ${e.message}", Toast.LENGTH_LONG).show()
                    }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Registrieren")
        }

        Spacer(Modifier.height(8.dp))

        TextButton(onClick = onNavigateBack, modifier = Modifier.fillMaxWidth()) {
            Text("Zurück zum Login")
        }
    }
}

// ---------------------------------------------------------------
// DASHBOARD SCREEN (nach Login)
// ---------------------------------------------------------------
@Composable
fun DashboardScreen(
    onSignOut: () -> Unit
) {
    val auth = FirebaseAuth.getInstance()
    val currentUser = auth.currentUser
    val firestore = FirebaseFirestore.getInstance()
    val context = LocalContext.current

    Column(
        Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {

        // Begrüßung
        Text(
            text = "Willkommen, ${currentUser?.email ?: "Unbekannt"}",
            style = MaterialTheme.typography.titleLarge
        )

        Spacer(Modifier.height(12.dp))

        // Abmelde-Button
        Button(
            onClick = {
                auth.signOut()
                Toast.makeText(context, "Erfolgreich abgemeldet", Toast.LENGTH_SHORT).show()
                onSignOut()
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Abmelden")
        }

        Spacer(Modifier.height(16.dp))

        // Beispiel: Anzahl der Projekte anzeigen
        var projectCount by remember { mutableStateOf<Int?>(null) }

        LaunchedEffect(Unit) {
            // Ich lade die Anzahl aller Projekte aus Firestore
            firestore.collection("projects").get()
                .addOnSuccessListener { snapshot ->
                    projectCount = snapshot.size()
                }
                .addOnFailureListener {
                    projectCount = null
                }
        }

        Text("Anzahl Projekte in der Datenbank: ${projectCount ?: "lädt…"}")
    }
}
